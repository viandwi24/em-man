<?php $__env->startSection('navbar'); ?> <!-- nv --> <?php $__env->stopSection(); ?>
<?php $__env->startSection('sidebar'); ?> <!-- nv --> <?php $__env->stopSection(); ?>
<?php $__env->startSection('footer'); ?> <!-- nv --> <?php $__env->stopSection(); ?>


<?php $__env->startSection('page'); ?>
    <div class="container">
        <div class="row pt-4">
            <div class="col-lg-6 offset-3">
                <div class="title text-center">
                    <h1>Selamat Datang di Em-man!</h1>
                    <p class="m-0">Employees Management App</p> 
                    <a href="<?php echo e(url()->route('login')); ?>" class="link text-primary">Admin Login</a>
                </div>
            </div>
        </div>
        <div class="row justify-content-center mt-4">
            <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                <div class="card card-statistic-1 shadow">
                    <div class="card-icon bg-primary"><i class="fas fa-user"></i></div>
                    <div class="card-wrap">
                        <div class="card-header">
                            <h4><?php echo e($item->nama); ?></h4>
                        </div>
                        <div class="card-body">
                            <?php echo e($item->karyawan()->count()); ?> Karyawan
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        
    <div class="row">
        <div class="col-lg-4 col-sm-12">
            <div class="card shadow">
                <div class="card-header"><h4>Daftar Unit</h4></div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <th>Unit</th>
                                <th>Jumlah Karyawan</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->karyawan()->count()); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-12">
            <div class="card shadow">
                <div class="card-header"><h4>Daftar Outsourcing</h4></div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <th>Outsourcing</th>
                                <th>Jumlah Karyawan</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $outsourcings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->karyawan()->count()); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4 col-sm-12">
            <div class="card shadow">
                <div class="card-header"><h4>Daftar Bagian</h4></div>
                <div class="card-body p-0">
                    <div class="table-responsive">
                        <table class="table table-hover table-bordered">
                            <thead>
                                <th>Bagian</th>
                                <th>Jumlah Karyawan</th>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td><?php echo e($item->karyawan()->count()); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('js'); ?>
    <script>$('.main-wrapper').remove()</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/home.blade.php ENDPATH**/ ?>