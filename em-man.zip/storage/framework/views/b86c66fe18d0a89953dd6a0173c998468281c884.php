<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2020 <div class="bullet"></div> 
        by <a href="https://nauval.in/">Your Name</a>
    </div>
    <div class="footer-right">
        <?php echo e(env('APP_NAME')); ?>

    </div>
</footer><?php /**PATH /home/viandwi24/code/em-man/resources/views/components/footer.blade.php ENDPATH**/ ?>