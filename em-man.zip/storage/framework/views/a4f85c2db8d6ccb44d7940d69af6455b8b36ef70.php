<?php $__env->startPush('js'); ?>
    <?php if(session('alert')): ?>
        <script>
            iziToast.success({ title: '<?php echo e(session("alert")["title"]); ?>', message: '<?php echo e(session("alert")["text"]); ?>', });
        </script>
    <?php endif; ?>

    <?php if($errors->any()): ?>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <script>iziToast.error({ title: 'Error', message: '<?php echo e($error); ?>', });</script>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopPush(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/components/alert-flash.blade.php ENDPATH**/ ?>