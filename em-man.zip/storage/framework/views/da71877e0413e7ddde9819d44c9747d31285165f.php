<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Edit Cuti</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url()->route('admin.cuti.update', [$cuti->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    
                    <div class="form-group">
                        <label>Karyawan</label>
                        <div>
                            <select value="<?php echo e(old('karyawan_id')); ?>" name="karyawan_id" class="form-control select2" style="width: 100%;">
                                <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(($item->id == $cuti->karyawan_id) ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4 col-sm-12">
                            <div class="form-group">
                                <label>Alasan</label>
                                <div>
                                    <input value="<?php echo e($cuti->alasan); ?>" type="text" name="alasan" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                            <div class="form-group">
                                <label>Tanggal Cuti</label>
                                <div>
                                    <input  value="<?php echo e($cuti->tanggal_cuti); ?>" type="text" name="tanggal_cuti" class="form-control datepicker">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-12">
                            <div class="form-group">
                                <label>Tanggal Masuk</label>
                                <div>
                                    <input  value="<?php echo e($cuti->tanggal_masuk); ?>" type="text" name="tanggal_masuk" class="form-control datepicker">
                                </div>
                            </div>
                        </div>
                    </div>

                    <button class="btn btn-primary float-right"><i class="fa fa-save"></i> Tambah</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css-library'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/select2/dist/css/select2.min.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-library'); ?>
    <script src="<?php echo e(asset('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/cuti/edit.blade.php ENDPATH**/ ?>