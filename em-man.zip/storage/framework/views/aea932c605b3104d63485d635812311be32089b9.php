<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Cuti</h4>
                <div class="card-header-action">
                    <a href="<?php echo e(url()->route('admin.cuti.create')); ?>" class="btn btn-success btn-icon"><i class="fa fa-plus"></i></a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-md table-striped" id="table">
                        <thead>
                            <th>ID</th>
                            <th>Karyawan</th>
                            <th>Alasan</th>
                            <th>Tanggal Cuti</th>
                            <th>Tanggal Masuk</th>
                            <th>...</th>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('assets/modules/datatables/datatables.min.js')); ?>"></script>
    <script>
        $('#table').DataTable( {
            ajax: "<?php echo e(url()->route('admin.cuti.index')); ?>",
            columns: [
                { data: 'id' },
                { data: 'karyawan.nama' },
                { data: 'alasan' },
                { data: 'tanggal_cuti' },
                { data: 'tanggal_masuk' },
                {
                    data: null,
                    render: function ( data, type, row ) {
                        return `
                        <div class="btn-group mb-3" role="group" aria-label="Basic example">
                            <a href="<?php echo e(url()->route('admin.cuti.index') . '/'); ?>`+data.id+`/edit" class="btn btn-sm btn-icon text-white btn-warning"><i class="fa fa-edit"></i></a>
                            <form method="post" action="<?php echo e(url()->route('admin.cuti.index') . '/'); ?>`+data.id+`">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-icon text-white btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                        </div>
                        `;
                    }
                }
            ]
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/cuti/index.blade.php ENDPATH**/ ?>