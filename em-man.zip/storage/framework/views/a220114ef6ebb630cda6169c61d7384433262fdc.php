<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Tambah Unit</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url()->route('admin.unit.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label>Nama</label>
                        <input type="text" name="nama" class="form-control">
                    </div>

                    <button class="btn btn-primary float-right"><i class="fa fa-save"></i> Tambah</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/unit/create.blade.php ENDPATH**/ ?>