<!DOCTYPE html>
<html lang="en">
<head>
    <title><?php echo e(env('APP_NAME')); ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php echo $__env->yieldPushContent('meta'); ?>
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
    <div id="app"><?php echo $__env->yieldPushContent('app'); ?></div>
    <?php echo $__env->yieldPushContent('js'); ?>
</body>
</html><?php /**PATH /home/viandwi24/code/em-man/resources/views/layouts/app.blade.php ENDPATH**/ ?>