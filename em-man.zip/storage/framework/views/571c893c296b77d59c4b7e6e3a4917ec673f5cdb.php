<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Peringatan</h4>
                <div class="card-header-action">
                    <a href="<?php echo e(url()->route('admin.peringatan.create')); ?>" class="btn btn-success btn-icon"><i class="fa fa-plus"></i></a>
                </div>
            </div>
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-md table-striped" id="table">
                        <thead>
                            <th>ID</th>
                            <th>Karyawan</th>
                            <th>Perihal</th>
                            <th>Nomor</th>
                            <th>Tanggal Pelanggaran</th>
                            <th>...</th>
                        </thead>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/datatables/DataTables-1.10.16/css/dataTables.bootstrap4.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js'); ?>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('assets/modules/datatables/datatables.min.js')); ?>"></script>
    <script>
        $('#table').DataTable( {
            ajax: "<?php echo e(url()->route('admin.peringatan.index')); ?>",
            columns: [
                { data: 'id' },
                { data: 'karyawan.nama' },
                { data: 'perihal' },
                { data: 'nomor' },
                { data: 'tanggal_pelanggaran' },
                {
                    data: null,
                    render: function ( data, type, row ) {
                        return `
                        <div class="btn-group mb-3" role="group" aria-label="Basic example">
                            <a target="_blank" href="<?php echo e(url()->route('admin.peringatan.index') . '/'); ?>`+data.id+`?berkas" class="btn btn-sm btn-icon text-white btn-success"><i class="fa fa-download"></i> </a>
                            <a href="<?php echo e(url()->route('admin.peringatan.index') . '/'); ?>`+data.id+`/edit" class="btn btn-sm btn-icon text-white btn-warning"><i class="fa fa-edit"></i></a>
                            <form method="post" action="<?php echo e(url()->route('admin.peringatan.index') . '/'); ?>`+data.id+`">
                                <?php echo method_field('delete'); ?>
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="btn btn-sm btn-icon text-white btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                        </div>
                        `;
                    }
                }
            ]
        });
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/peringatan/index.blade.php ENDPATH**/ ?>