<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Edit Mutasi</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url()->route('admin.mutasi.update', [$mutasi->id])); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('put'); ?>
                    
                    <div class="row">
                        <div class="col-lg-9 col-sm-12">
                            <div class="form-group">
                                <label>Karyawan</label>
                                <div>
                                    <select value="<?php echo e($mutasi->karyawan_id); ?>" name="karyawan_id" class="form-control select2" style="width: 100%;">
                                        <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $mutasi->karyawan_id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-sm-12">
                            <div class="form-group">
                                <label>Tanggal</label>
                                <div>
                                    <input value="<?php echo e($mutasi->tanggal); ?>" type="text" name="tanggal" class="form-control datepicker">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Unit</label>
                                <div>
                                    <select value="<?php echo e($mutasi->unit_id); ?>" name="unit_id" class="form-control select2" style="width: 100%;">
                                        <option value="" selected>--Pilih unit--</option>
                                        <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $mutasi->unit_id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Outsourcing</label>
                                <div>
                                    <select value="<?php echo e($mutasi->outsourcing_id); ?>" name="outsourcing_id" class="form-control select2" style="width: 100%;">
                                        <option value="" selected>--Pilih outsourcing--</option>
                                        <?php $__currentLoopData = $outsourcings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $mutasi->outsourcing_id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Bagian</label>
                                <div>
                                    <select value="<?php echo e($mutasi->bagian_id); ?>" name="bagian_id" class="form-control select2" style="width: 100%;">
                                        <option value="" selected>--Pilih bagian--</option>
                                        <?php $__currentLoopData = $bagians; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $mutasi->bagian_id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Jabatan</label>
                                <div>
                                    <select value="<?php echo e($mutasi->jabatan_id); ?>" name="jabatan_id" class="form-control select2" style="width: 100%;">
                                        <option value="" selected>--Pilih jabatan--</option>
                                        <?php $__currentLoopData = $jabatans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>" <?php echo e($item->id == $mutasi->jabatan_id ? 'selected' : ''); ?>><?php echo e($item->nama); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                    </div>

                    <button class="btn btn-primary float-right"><i class="fa fa-save"></i> Tambah</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css-library'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/select2/dist/css/select2.min.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-library'); ?>
    <script src="<?php echo e(asset('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/mutasi/edit.blade.php ENDPATH**/ ?>