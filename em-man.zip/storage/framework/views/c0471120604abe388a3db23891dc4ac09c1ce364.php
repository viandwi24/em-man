<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
    <style type="text/css">
		table tr td, table tr th{ font-size: 9pt; }
    </style>

    <div class="text-center mb-4 mt-4">
        <h5>Data Karyawan</h4>
    </div>
    
    <div>
        <h6>1. DATA PRIBADI</h6>
        <table>
            <tr>
                <td width="50%">
                    <table>
                        <tr>
                            <th style="padding-right: 2rem;">ID</th>
                            <td>: <?php echo e($karyawan->id); ?></td>
                        </tr>
                        <tr>
                            <th style="padding-right: 2rem;">Nama</th>
                            <td>: <?php echo e($karyawan->nama); ?></td>
                        </tr>
                        <tr>
                            <th style="padding-right: 2rem;">NIK</th>
                            <td>: <?php echo e($karyawan->nik); ?></td>
                        </tr>
                        <tr>
                            <th style="padding-right: 2rem;">Tempat Lahir</th>
                            <td>: <?php echo e($karyawan->tempat_lahir); ?></td>
                        </tr>
                        <tr>
                            <th style="padding-right: 2rem;">Tanggal Lahir</th>
                            <td>: <?php echo e($karyawan->tanggal_lahir); ?></td>
                        </tr>
                        <tr>
                            <th style="padding-right: 2rem;">Alamat</th>
                            <td>: <?php echo e($karyawan->alamat); ?></td>
                        </tr>
                        <tr>
                            <th style="padding-right: 2rem;">Tanggal Masuk Kerja</th>
                            <td>: <?php echo e($karyawan->tanggal_masuk); ?></td>
                        </tr>
                    </table>
                </td>
                <td width="50%" style="text-align: right;padding-left: 15rem;">
                    <img alt="image" src="<?php echo e(url()->route('foto_karyawan', [$karyawan->foto])); ?>" width="150" style="display: inline-block;">
                </td>
            </tr>
        </table>
    </div>

    <div style="margin-top: 2rem;">
        <h6>2. Pendidikan Terakhir</h6>

        <table>
            <tr>
                <th style="padding-right: 2rem;">Jenjang</th>
                <td>: <?php echo e($karyawan->pendidikan->jenjang); ?></td>
            </tr>
            <tr>
                <th style="padding-right: 2rem;">Nama</th>
                <td>: <?php echo e($karyawan->pendidikan->nama); ?></td>
            </tr>
            <tr>
                <th style="padding-right: 2rem;">Jurusan</th>
                <td>: <?php echo e($karyawan->pendidikan->jurusan); ?></td>
            </tr>
            <tr>
                <th style="padding-right: 2rem;">Tahun lulus</th>
                <td>: <?php echo e($karyawan->pendidikan->tahun_lulus); ?></td>
            </tr>
            <tr>
                <th style="padding-right: 2rem;">Nomor Ijazah</th>
                <td>: <?php echo e($karyawan->pendidikan->nomor_ijazah); ?></td>
            </tr>
        </table>
    </div>


    <div style="margin-top: 2rem;">
        <h6>3. Riwayat Pekerjaan</h6>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Bagian</th>
                    <th>Jabatan</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $karyawan->mutasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($item->tanggal); ?></td>
                    <td><?php echo e($item->bagian->nama); ?></td>
                    <td><?php echo e($item->jabatan->nama); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 2rem;">
        <h6>4. Riwayat Peringatan</h6>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tanggal</th>
                    <th>Nomor</th>
                    <th>Perihal</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $karyawan->peringatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($item->tanggal_pelanggaran); ?></td>
                    <td><?php echo e($item->nomor); ?></td>
                    <td><?php echo e($item->perihal); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div style="margin-top: 2rem;">
        <h6>5. Riwayat Cuti</h6>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>#</th>
                    <th>Tanggal Cuti</th>
                    <th>Lama Cuti</th>
                    <th>Alasan</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1; ?>
                <?php $__currentLoopData = $karyawan->cuti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($i); ?></td>
                    <td><?php echo e($item->tanggal_cuti); ?></td>
                    <td>
                        <?php
                            $to = \Carbon\Carbon::parse($item->tanggal_masuk);
                            $from = \Carbon\Carbon::parse($item->tanggal_cuti);
                            $diff_in_days = $to->diffInDays($from);
                            echo $diff_in_days;
                        ?>
                        Hari
                    </td>
                    <td><?php echo e($item->alasan); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/laporan/pdf_show.blade.php ENDPATH**/ ?>