<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>PDF</title>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap/css/bootstrap.min.css')); ?>">
</head>
<body>
    <style type="text/css">
		table tr td, table tr th{ font-size: 8pt; }
    </style>

    <div class="text-center mb-4 mt-4">
        <h5>Laporan Karyawan</h4>
    </div>
    
    <table class='table table-bordered'>
        <thead>
            <tr>
                <th>#</th>
                <th>ID</th>
                <th>Nama</th>
                <th>Unit</th>
                <th>Outsourcing</th>
                <th>Bagian</th>
                <th>Jabatan</th>
                <th>Peringatan</th>
                <th>Cuti</th>
            </tr>
        </thead>
        <tbody>
            <?php $i=1 ?>
            <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $karyawan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($karyawan->id); ?></td>
                <td><?php echo e($karyawan->nama); ?></td>
                <td><?php echo e($karyawan->unit->nama); ?></td>
                <td><?php echo e($karyawan->outsourcing->nama); ?></td>
                <td><?php echo e($karyawan->bagian->nama); ?></td>
                <td><?php echo e($karyawan->jabatan->nama); ?></td>
                <td><?php echo e(($karyawan->peringatan->count() == 0) ? '-' : $karyawan->peringatan->count() . 'x'); ?></td>
                <td><?php echo e(($karyawan->cuti->count() == 0) ? '-' : $karyawan->cuti->count() . 'x'); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</body>
</html><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/laporan/pdf.blade.php ENDPATH**/ ?>