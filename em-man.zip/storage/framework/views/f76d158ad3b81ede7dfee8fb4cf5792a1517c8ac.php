<?php
$menus = [
    [ 'type' => 'item', 'text' => 'Dashboard', 'icon' => 'fas fa-home', 'url' => url()->route('admin.home') ],

    [ 'type' => 'treeview', 'text' => 'Manajemen', 'icon' => 'fas fa-tasks', 'item' => [
        [ 'type' => 'item', 'text' => 'Unit', 'icon' => 'fas fa-building', 'url' => url()->route('admin.unit.index') ],
        [ 'type' => 'item', 'text' => 'Outsourcing', 'icon' => 'fas fa-synagogue', 'url' => url()->route('admin.outsourcing.index') ],
        [ 'type' => 'item', 'text' => 'Bagian', 'icon' => 'fas fa-briefcase', 'url' => url()->route('admin.bagian.index') ],
        [ 'type' => 'item', 'text' => 'Jabatan', 'icon' => 'fas fa-id-badge', 'url' => url()->route('admin.jabatan.index') ],
        [ 'type' => 'item', 'text' => 'Karyawan', 'icon' => 'fas fa-user-tie', 'url' => url()->route('admin.karyawan.index') ],
    ]],

    [ 'type' => 'treeview', 'text' => 'Karyawan', 'icon' => 'fas fa-user-tie', 'item' => [
        [ 'type' => 'item', 'text' => 'Mutasi', 'icon' => 'fas fa-paper-plane', 'url' => url()->route('admin.mutasi.index') ],
        [ 'type' => 'item', 'text' => 'Cuti', 'icon' => 'fas fa-hourglass-half', 'url' => url()->route('admin.cuti.index') ],
        [ 'type' => 'item', 'text' => 'Surat Peringatan', 'icon' => 'fas fa-scroll', 'url' => url()->route('admin.peringatan.index') ],
    ]],
    
    [ 'type' => 'treeview', 'text' => 'Perusahaan', 'icon' => 'fas fa-building', 'item' => [
        [ 'type' => 'item', 'text' => 'Rencana Kerja', 'icon' => 'fas fa-list-alt', 'url' => url()->route('admin.rencana.index') ],
    ]],

    [ 'type' => 'treeview', 'text' => 'Laporan', 'icon' => 'fas fa-chart-line', 'item' => [
        [ 'type' => 'item', 'text' => 'Laporan Karyawan', 'icon' => 'fas fa-chart-line', 'url' => url()->route('admin.laporan') ],
    ]],
]
?>
<div class="main-sidebar sidebar-style-2">
    <aside id="sidebar-wrapper">
        <div class="sidebar-brand">
            <a href="<?php echo e(url()->route('admin.home')); ?>">
                Em-Man
            </a>
        </div>
        <div class="sidebar-brand sidebar-brand-sm">
            <a href="<?php echo e(url()->route('admin.home')); ?>">eM</a>
        </div>
        <ul class="sidebar-menu">
            <?php $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($item['type'] == 'item'): ?>
                    <li class="<?php echo e(url()->current() == $item['url'] ? ' active' : ''); ?>">
                        <a class="nav-link" href="<?php echo e($item['url']); ?>">
                            <i class="<?php echo e($item['icon']); ?>"></i> <span><?php echo e($item['text']); ?></span>
                        </a>
                    </li>
                <?php elseif($item['type'] == 'treeview'): ?>
                    <?php $active = ''; ?>
                    <?php for($i = 0; $i < count($item['item']); $i++): ?>
                        <?php 
                        if (url()->current() == $item['item'][$i]['url'] ? ' active' : '')
                        {
                            $active = ' active';
                            break;
                        }
                        ?>
                    <?php endfor; ?>
                    <li class="dropdown<?php echo e($active); ?>">
                        <a href="#" class="nav-link has-dropdown" data-toggle="dropdown">
                            <i class="<?php echo e(@$item['icon']); ?>"></i> <span><?php echo e($item['text']); ?></span>
                        </a>
                        <ul class="dropdown-menu">
                            <?php $__currentLoopData = $item['item']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subitem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="<?php echo e(url()->current() == $subitem['url'] ? ' active' : ''); ?>">
                                <a class="nav-link" href="<?php echo e($subitem['url']); ?>">
                                    <span><?php echo e($subitem['text']); ?></span>
                                </a>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </li>
                <?php elseif($item['type'] == 'header'): ?>
                    <li class="menu-header"><?php echo e($item['text']); ?></li>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </aside>
</div><?php /**PATH /home/viandwi24/code/em-man/resources/views/components/sidebar.blade.php ENDPATH**/ ?>