<?php $__env->startSection('content'); ?>
    <div class="col-12">
        <div class="card">
            <div class="card-header">
                <h4>Tambah Peringatan</h4>
            </div>
            <div class="card-body">
                <form action="<?php echo e(url()->route('admin.peringatan.store')); ?>" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    
                    <div class="form-group">
                        <label>Karyawan</label>
                        <div>
                            <select value="<?php echo e(old('karyawan_id')); ?>" name="karyawan_id" class="form-control select2" style="width: 100%;">
                                <option value="" selected>--Pilih Karyawan--</option>
                                <?php $__currentLoopData = $karyawans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>"><?php echo e($item->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Perihal</label>
                                <div>
                                    <input type="text" name="perihal" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Nomor</label>
                                <div>
                                    <input type="text" name="nomor" class="form-control">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Pelanggaran</label>
                                <div>
                                    <input type="text" name="pelanggaran" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 col-sm-12">
                            <div class="form-group">
                                <label>Tanggal Pelanggaran</label>
                                <div>
                                    <input type="text" name="tanggal_pelanggaran" class="form-control datepicker">
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="form-group">
                        <label>Berkas Surat</label>
                        <div>
                            <input type="file" name="berkas" class="form-control">
                        </div>
                    </div>

                    <button class="btn btn-primary float-right"><i class="fa fa-save"></i> Tambah</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('css-library'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/select2/dist/css/select2.min.css')); ?>"> 
    <link rel="stylesheet" href="<?php echo e(asset('assets/modules/bootstrap-daterangepicker/daterangepicker.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startPush('js-library'); ?>
    <script src="<?php echo e(asset('assets/modules/select2/dist/js/select2.full.min.js')); ?>"></script>  
    <script src="<?php echo e(asset('assets/modules/bootstrap-daterangepicker/daterangepicker.js')); ?>"></script>  
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/viandwi24/code/em-man/resources/views/pages/admin/peringatan/create.blade.php ENDPATH**/ ?>