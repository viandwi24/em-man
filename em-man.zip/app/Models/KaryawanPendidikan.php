<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class KaryawanPendidikan extends Model
{
    protected $table = 'karyawan_pendidikan';
    protected $guarded = [];
}
