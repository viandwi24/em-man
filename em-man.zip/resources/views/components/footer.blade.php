<footer class="main-footer">
    <div class="footer-left">
        Copyright &copy; 2020 <div class="bullet"></div> 
        by <a href="https://nauval.in/">Your Name</a>
    </div>
    <div class="footer-right">
        {{ env('APP_NAME') }}
    </div>
</footer>